import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
from scipy.interpolate import interp1d
 
 
def compute_mie(original, reconstructed, range_min=None, range_max=None):
    """
    Calculates the Mean Integrated Error (MIE) between two signals.
 
    Args:
        original (numpy.ndarray): The original signal.
        reconstructed (numpy.ndarray): The reconstructed signal.
        range_min (float, optional): The minimum value of the range. Defaults to None.
        range_max (float, optional): The maximum value of the range. Defaults to None.
 
    Returns:
        float: The MIE value.
    """
 
    # Ensure both signals have the same shape
    if original.shape != reconstructed.shape:
        raise ValueError("Original and reconstructed signals must have the same shape")
 
    # If range_min and range_max are not specified, use the minimum and maximum values in the signals
    if range_min is None:
        range_min = min(np.min(original), np.min(reconstructed))
    if range_max is None:
        range_max = max(np.max(original), np.max(reconstructed))
 
    # Calculate the range size
    range_size = range_max - range_min
 
    # Calculate the integral of the absolute difference between the signals
    integral_error = np.sum(np.abs(original - reconstructed))
 
    # Calculate MIE
    return integral_error / (original.size * range_size)
 
 
def compute_psnr(original, reconstructed, max_value=255):
    """
    Calculates the Peak Signal-to-Noise Ratio (PSNR) between two images.
 
    Args:
        original (numpy.ndarray): The original image.
        reconstructed (numpy.ndarray): The reconstructed image.
        max_value (float, optional): The maximum pixel value (usually 255 for 8-bit images). Defaults to 255.
 
    Returns:
        float: The PSNR value in dB.
    """
 
    # Ensure both signals have the same shape
    if original.shape != reconstructed.shape:
        raise ValueError("Original and reconstructed signals must have the same shape")
 
    # Calculate mean squared error
    mse = np.mean((original - reconstructed) ** 2)
 
    # Calculate PSNR
    return 10 * np.log10((max_value ** 2) / mse)
 
 
def inverse_fourier_transform(sampled_frequencies):
    """
    Performs the inverse Fourier transform on a 2D array representing the sampled frequencies.
 
    Args:
        sampled_frequencies (numpy.ndarray): The sampled frequencies in the frequency domain.
 
    Returns:
        numpy.ndarray: The reconstructed image in the spatial domain.
    """
 
    return np.fft.ifft2(np.fft.ifftshift(sampled_frequencies)).real
 
 
def frequency_domain_interpolation(sampled_frequency_domain, output_shape):
    """
    Perform Frequency Domain Interpolation (FDI) to reconstruct an image from the sampled frequency domain.
 
    Parameters:
    - sampled_frequency_domain (numpy.ndarray): Sampled frequency domain representation of the image.
    - output_shape (tuple): Shape of the output image (height, width).
 
    Returns:
    - reconstructed_image (numpy.ndarray): Reconstructed image.
    """
 
    if not isinstance(sampled_frequency_domain, np.ndarray):
        raise ValueError("Input 'sampled_frequency_domain' must be a NumPy array")
 
    if not isinstance(output_shape, tuple):
        raise ValueError("Input 'output_shape' must be a tuple")
 
    # Determine the number of projections
    num_projections = sampled_frequency_domain.shape[0]
 
    # Create interpolation functions for each projection angle
    interpolation_functions = []
    for i in range(num_projections):
        angle_projection = np.linspace(0, np.pi, sampled_frequency_domain.shape[1])
        interpolation_functions.append(interp1d(angle_projection, sampled_frequency_domain[i], kind='linear', fill_value="extrapolate"))
 
    # Create a new frequency domain grid for the desired output shape
    new_angle_projection = np.linspace(0, np.pi, output_shape[1])
    new_frequency_domain = np.zeros((num_projections, output_shape[1]), dtype=np.complex128)
 
    # Interpolate to get the full set of projections
    for i in range(num_projections):
        new_frequency_domain[i] = interpolation_functions[i](new_angle_projection)
 
    # Perform inverse Fourier transform
    reconstructed_image = np.fft.ifft2(np.fft.ifftshift(new_frequency_domain)).real
 
    # Resize the reconstructed image to match the output shape
    reconstructed_image_resized = cv2.resize(reconstructed_image.astype(np.uint8), output_shape[::-1], interpolation=cv2.INTER_LINEAR)
 
    return reconstructed_image_resized
 
 
def radial_non_uniform_sampling(frequencies, sampling_ratio):
    """
    Samples a given set of frequencies non-uniformly in a radial pattern.
 
    Args:
        frequencies (numpy.ndarray): The original frequencies.
        sampling_ratio (float): The ratio of frequencies to sample (0 to 1).
 
    Returns:
        numpy.ndarray: The sampled frequencies.
    """
 
    num_samples = int(frequencies.size * sampling_ratio)
    center = np.array(frequencies.shape) / 2
    radius = min(frequencies.shape) / 2
    sampled_indices = np.random.choice(np.arange(frequencies.size), num_samples, replace=False)
    sampled_indices = np.unravel_index(sampled_indices, frequencies.shape)
    sampled_indices = np.array(sampled_indices).T
    sampled_indices = sampled_indices - center
    distances = np.linalg.norm(sampled_indices, axis=1)
    sampled_indices = sampled_indices[distances <= radius]
    sampled_indices = sampled_indices + center
    sampled_indices = sampled_indices.astype(int)
    sampled_frequencies = np.zeros_like(frequencies)
    sampled_frequencies[sampled_indices[:, 0], sampled_indices[:, 1]] = frequencies[sampled_indices[:, 0], sampled_indices[:, 1]]
    return sampled_frequencies
 
 
# Load dataset
images = r"C:\Users\cliff\Downloads\imgs\imgs"
 
num_images = 1
img_files = os.listdir(images)[:num_images]
 
# Placeholder for results
mie_results_inuft = []
psnr_results_inuft = []
mie_results_fdi = []
psnr_results_fdi = []
 
for i, img in enumerate(img_files):
    img_path = os.path.join(images, img)
    img_curr = cv2.imread(img_path)
    img_gray = np.mean(img_curr, axis=2)
 
    # Perform Fourier transform
    f = np.fft.fft2(img_gray)
    fshift = np.fft.fftshift(f)
 
    # Radial non-uniform sampling
    sampling_ratio = 0.8  # Adjust this ratio as needed
    sampled_fshift = radial_non_uniform_sampling(fshift, sampling_ratio)
 
    # Inverse Fourier transform (INUFT)
    reconstructed_img_gray_inuft = inverse_fourier_transform(sampled_fshift)
 
    # Frequency Domain Interpolation (FDI)
    output_shape = img_gray.shape
    reconstructed_img_gray_fdi = frequency_domain_interpolation(np.abs(sampled_fshift), output_shape)
 
    # Calculate MIE and PSNR for INUFT
    mie_inuft = compute_mie(img_gray, reconstructed_img_gray_inuft)
    psnr_inuft = compute_psnr(img_gray, reconstructed_img_gray_inuft)
    mie_results_inuft.append(mie_inuft)
    psnr_results_inuft.append(psnr_inuft)
 
    # Calculate MIE and PSNR for FDI
    mie_fdi = compute_mie(img_gray, reconstructed_img_gray_fdi)
    psnr_fdi = compute_psnr(img_gray, reconstructed_img_gray_fdi)
    mie_results_fdi.append(mie_fdi)
    psnr_results_fdi.append(psnr_fdi)
 
    plt.figure(figsize=(10, 6))
 
    plt.subplot(1, 3, 1)
    plt.imshow(img_gray, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')
 
    plt.subplot(1, 3, 2)
    plt.imshow(reconstructed_img_gray_inuft, cmap='gray')
    plt.title('Reconstructed Image (INUFT)')
    plt.axis('off')
 
    plt.subplot(1, 3, 3)
    plt.imshow(reconstructed_img_gray_fdi, cmap='gray')
    plt.title('Reconstructed Image (FDI)')
    plt.axis('off')
 
    plt.tight_layout()
    plt.show()
 
# Display evaluation results for INUFT
print("Evaluation results for INUFT:")
print("Mean Integrated Error (MIE):", np.mean(mie_results_inuft))
print("Peak Signal-to-Noise Ratio (PSNR):", np.mean(psnr_results_inuft))
 
# Display evaluation results for FDI
print("Evaluation results for FDI:")
print("Mean Integrated Error (MIE):", np.mean(mie_results_fdi))
print("Peak Signal-to-Noise Ratio (PSNR):", np.mean(psnr_results_fdi))