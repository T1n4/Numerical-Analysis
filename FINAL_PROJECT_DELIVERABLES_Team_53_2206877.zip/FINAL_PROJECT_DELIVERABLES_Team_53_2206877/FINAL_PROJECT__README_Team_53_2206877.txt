# Signal Reconstruction from Non-Uniform Frequency Sampling

This project is developed using Python and utilizes several libraries for its functionality.

## Requirements

- Python version 3.9 or higher
- Libraries: numpy, scikit, opencv, matplotlib, os

These libraries and the respective Python versions must be installed to run the project. The project can be run on IDEs like PyCharm, Jupyter Notebook, etc.

## Running the Project

To run the project in the terminal, place the source file in the directory that you want to run in, then use the following command:

```bash
python FINAL_PROJECT_CODE_Team53_2206877.py

